CREATE PROCEDURE getSum(IN n INT)
  BEGIN
  DECLARE i,s INT ;#定义变量
  SET i =1,s=0; #设置变量值
  WHILE i<=n DO
  SET s=s+i;
  SET i=i+1;
  END WHILE;
  SELECT s;
END;

