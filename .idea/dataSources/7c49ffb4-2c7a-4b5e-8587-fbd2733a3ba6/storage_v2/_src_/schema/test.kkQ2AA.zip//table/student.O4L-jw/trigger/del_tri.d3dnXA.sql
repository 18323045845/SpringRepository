CREATE TRIGGER del_tri
  AFTER DELETE
  ON student
  FOR EACH ROW
  BEGIN 
#定义一个变量用来存储班级人数
DECLARE i INT;
SET i=(SELECT stu_num  FROM class  WHERE cid = old.cid);
UPDATE class SET stu_num=i-1 WHERE cid=old.cid;
END;

